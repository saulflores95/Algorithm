Titulo: Listas Enlazadas
No. de practica: 7
Alumno: Flores Torres Coto Saul Ivan
Matricula: 01217102

Como ejecutar jar

'java -jar practica7.jar'

sin las comillas simples
