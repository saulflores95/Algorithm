Para ejecturar el archivo .jar:

1. Asegurar que se encuentre en el mismo directorio
2. java -jar polinomioColaFloresSaul.jar
3. Imporntate notar que cuando se ingresa los valores del polinomio es necesario
ingresar el valor del grado mayor a menor(En forma descendete) para mejor visualizacion

 
